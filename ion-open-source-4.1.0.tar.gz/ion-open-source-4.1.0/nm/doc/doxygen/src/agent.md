NM Agent                              {#nmagent}
=======

Network Management Agent implementing the Asynchronous Management
Protocol (AMP).  It listens for commands and sends reports to the
configured manager endpoint.

## Usage

> nm_agent agent_eid manager_eid

